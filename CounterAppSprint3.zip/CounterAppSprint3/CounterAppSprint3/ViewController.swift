//
//  ViewController.swift
//  CounterAppSprint3
//
//  Created by Asya  on 05.10.2022.
//

import UIKit

class ViewController: UIViewController {
    var didTap: Bool = true
    private var score = 0
    
    @IBOutlet weak var counterValueLabel: UILabel!
    @IBOutlet weak var changeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonDidTap(_ sender: Any) {
       score += 1
        if didTap {
          
            counterValueLabel.text = "Значение счетчика: \(score)"
        }
        
    }
}
